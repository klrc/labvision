from .auto_control import AutoControl
