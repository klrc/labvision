num_workers_limit = 4


def limit(max_num_workers):
    global num_workers_limit
    num_workers_limit = max_num_workers
