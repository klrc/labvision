def clean():
    raise NotImplementedError


def check_dirs():
    raise NotImplementedError


def pack():
    raise NotImplementedError


def deploy():
    raise NotImplementedError
