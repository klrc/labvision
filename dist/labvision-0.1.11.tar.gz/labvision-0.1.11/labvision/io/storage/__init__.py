disk_limit = None


def limit():
    print('storage limit func.')
    raise NotImplementedError
