class GIF():
    def __init__(self):
        pass
